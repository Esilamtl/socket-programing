/*
* Emircan Görkem ECE - 210303049
* Ebrar Esila Mutlu - 190303066
*/

public class Client {
    public static void main(String[] args) throws InterruptedException {
        ExecuteClient ec = new ExecuteClient();
        ec.run();
    }
}