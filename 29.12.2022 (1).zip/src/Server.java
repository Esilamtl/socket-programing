/*
 * Emircan Görkem ECE - 210303049
 * Ebrar Esila Mutlu - 190303066
 */

public class Server {
    public static void main(String[] args) throws InterruptedException {
        ExecuteServer e = new ExecuteServer();
        e.run();
    }
}